-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 02, 2020 at 02:13 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ave`
--

-- --------------------------------------------------------

--
-- Table structure for table `alyssa`
--

CREATE TABLE `alyssa` (
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `about_me` text NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `alyssa`
--

INSERT INTO `alyssa` (`fname`, `lname`, `email`, `gender`, `about_me`, `address`) VALUES
('Alyssa', 'Ave', 'avealyssa13@gmail.com', 'Female', 'Good Day! I’m Alyssa P. Ave. I’m from a middle-class family of my hometown. I was an invader of this City for I came from to other province which is (Surigao del Sur). I was studying Bachelor of Science in Information Technology at the best school in the city (Father Saturnino Urios University). The course widen my ability to computer world and always been my curiosity since then. Aside from studies, I’m quite sporty and back then I was a former athlete during my high school days. I am very adventurous person too and I like staying in some beaches, that’s really my stress reliever. During free time, I spend most of the time with my friends or my siblings at the beach. A company with them completes my day, knowing that there are people who you can rely every time. My parents are my best motivation in life, realizing the hardships and sacrifices they exert on me turn me into a whole person.', 'Mangagoy, Bislig City, Surigao del Sur');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
