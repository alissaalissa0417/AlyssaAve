<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php  

									if ($tbl_pla) {
										foreach ($tbl_pla as $data) {
											    echo $data->fname." ".$data->lname;
											}	
									}


								?></title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
	<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
</head>
<body>


	<main>
		<!-- color black -->
		<div class="main">
			<!-- flex -->
			<div class="head">
				<div class="name">
					<p><?php  

									if ($tbl_pla) {
										foreach ($tbl_pla as $data) {
											    echo $data->fname." ".$data->lname;
											}	
									}


								?></p>
				</div>
				<div class="list">
					<ul>
						<li><span onclick="port();">portfolio</span></li>
						<li><span>services</span></li>
						<li><span>contact</span></li>
					</ul>
				</div>
			</div>
			<!-- end of flex -->

				<!-- box -->

				<div class="box">
					<div class="content_box">
						<div class="column">
							<div class="person">
								<p>alyysa photography studio</p>
							</div>
							<div class="person">
								<p>treasure your shots</p>
							</div>
							<div class="person">
								<p>book now</p>
							</div>
						</div>
					</div>
				</div>


				<!-- facebook -->

				<div class="social">
					<div class="social_list">
						<ul>
							<li><span>facebook</span></li>
							<li><span>instagram</span></li>
						</ul>
					</div>
				</div>


				<!-- end of facebook -->

	<!-- end of box -->

		</div>
		<!-- end of color black -->
	</main>


	<script type="text/javascript">
		

		function port(){
			window.location.href="<?php echo base_url('Ave_cont/portfolio'); ?>";
		}

	</script>


</body>
</html>