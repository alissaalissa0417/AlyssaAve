<?php  

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * summary
 */
class Ave_cont extends CI_Controller
{
    /**
     * summary
     */

    function __construct(){
    	parent:: __construct();
    	$this->load->model('ave','data');
    }

    function index(){
    	$data['tbl_pla'] = $this->data->getdata();
    	$this->load->view('main/index',$data);
    }

    function portfolio(){
        $data['tbl_pla'] = $this->data->getdata();
        $this->load->view('main/port',$data);
    }
}

?>