######## INSTALLATION FOR MY WEB APPLICATION ##############


STEP 1: YOU MUST IMPORT THE ave.sql in localhost.
STEP 2: AFTER YOU UPLOADED THE FILE. THE DATABASE NAME IS "ave" DATABASE TABLE IS "alyssa".
STEP 3: NOW VISIT THIS LINK: http://localhost/ave/Ave_cont/index